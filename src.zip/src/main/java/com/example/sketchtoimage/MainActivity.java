package com.example.sketchtoimage;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sketchtoimage.ml.SketchToImageModel;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    ImageView inputImageView, outputImageView;
    Button processButton, chooseImageButton;
    ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputImageView = findViewById(R.id.inputImageView);
        outputImageView = findViewById(R.id.outputImageView);
        processButton = findViewById(R.id.processButton);
        chooseImageButton = findViewById(R.id.chooseImageButton);

        // Initialize ExecutorService for background tasks
        executorService = Executors.newSingleThreadExecutor();

        // Button to choose image from gallery
        chooseImageButton.setOnClickListener(view -> openImageChooser());

        // Process the selected image in the background
        processButton.setOnClickListener(view -> {
            Bitmap inputBitmap = ((BitmapDrawable) inputImageView.getDrawable()).getBitmap();
            if (inputBitmap != null) {
                // Run image processing on a background thread
                executorService.submit(() -> processImage(inputBitmap));
            } else {
                Toast.makeText(MainActivity.this, "Please select an image first", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openImageChooser() {
        // Intent to open the image gallery
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*"); // Restrict to images
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    // Handle the result of the image chooser
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            try {
                // Get the image from the URI
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                inputImageView.setImageBitmap(bitmap); // Set the image in ImageView
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void processImage(Bitmap inputBitmap) {
        try {
            // Load the TensorFlow Lite model
            SketchToImageModel model = SketchToImageModel.newInstance(getApplicationContext());

            // Prepare the input tensor (Ensure model input size is correct, e.g., 218x178)
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 218, 178, 3}, DataType.FLOAT32);
            ByteBuffer byteBuffer = convertBitmapToByteBuffer(inputBitmap); // Ensure correct image size
            inputFeature0.loadBuffer(byteBuffer);

            // Run inference
            SketchToImageModel.Outputs outputs = model.process(inputFeature0);
            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

            // Convert output tensor to Bitmap
            Bitmap outputBitmap = convertByteBufferToBitmap(outputFeature0.getBuffer(), 218, 178);

            // Update the UI with the output image on the main thread
            runOnUiThread(() -> outputImageView.setImageBitmap(outputBitmap));

            // Release model resources
            model.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ByteBuffer convertBitmapToByteBuffer(Bitmap bitmap) {
        // Resize the image to match model input size (218x178)
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, 218, 178, true);
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * 218 * 178 * 3); // Adjust buffer size
        byteBuffer.order(ByteOrder.nativeOrder());
        int[] intValues = new int[218 * 178];  // Ensure correct size
        resizedBitmap.getPixels(intValues, 0, 218, 0, 0, 218, 178);

        // Normalize and store pixel values in ByteBuffer
        for (int pixelValue : intValues) {
            byteBuffer.putFloat(((pixelValue >> 16) & 0xFF) / 255.0f); // Red
            byteBuffer.putFloat(((pixelValue >> 8) & 0xFF) / 255.0f);  // Green
            byteBuffer.putFloat((pixelValue & 0xFF) / 255.0f);         // Blue
        }
        return byteBuffer;
    }

    private Bitmap convertByteBufferToBitmap(ByteBuffer buffer, int width, int height) {
        buffer.rewind();
        int[] pixels = new int[width * height];
        for (int i = 0; i < width * height; i++) {
            int r = (int) (buffer.getFloat() * 255);
            int g = (int) (buffer.getFloat() * 255);
            int b = (int) (buffer.getFloat() * 255);
            pixels[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
        }
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888);
    }
}
